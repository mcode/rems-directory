# Disclaimer

This SPL Zip file information is test data not to be representative of real world SPL information. While they are based on the actual SPL Zip from FDA, the files have been modified for the purposes of the REMS prototype and may even be out of date. The data in these files are not intended for medical use.